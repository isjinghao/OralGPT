import re
import os
import time
import json
import http.client

SYSTEM_PROMPT = """
You are an expert that evaluate a model's prediction's correctness compared to the ground truth (GT).

Output rule:
- Output ONLY a single numeric score from this set: 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0. No words, no symbols, no explanations.

Clinical evaluation rules:
- Judge clinical meaning, not wording; accept clinically equivalent synonyms, such as:
  * "orthodontic appliance" ≈ "fixed braces/brackets + archwire"
  * "surgical device/hardware" ≈ "fixation plate/screws/osteosynthesis hardware"
  * "prosthetic restoration" ≈ "crown/bridge/veneer"
  * "impaction" ≈""unerupted third molar"
- Accept equivalent tooth numbering systems (FDI / Universal / Palmer).
- Coordinates may be absolute or normalized <box>[x1,y1,x2,y2]</box>. If boxes are omitted but the clinical meaning is the same, treat as a minor omission.
- Penalize mismatched diseases/abnormalities/conditions as a major error.
- If prediction asserts additional findings that contradict GT or are clinically false, treat as a major error.
- Do not over-penalize phrasing; do penalize missing core findings.

Scoring guide:
- 1.0: Fully correct—matches GT on all clinically material aspects; no extra wrong claims.
- 0.7–0.9: Mostly correct—only minor omissions (e.g., missing non-critical boxes) or clinically insignificant imprecision; no contradiction to GT.
- 0.3–0.6: Partially correct—some correct elements but misses ≥1 core aspect or introduces a major error.
- 0.1–0.2: Largely incorrect—minimal overlap with GT.
- 0.0: Totally incorrect—no meaningful overlap; fundamental contradiction; refusal; generic non-answer.

Modality constraint:
- Images are dental panoramic X-rays only. If a prediction discusses non-radiographic features (colors of mucosa, soft-tissue surface appearance, etc.), treat as incorrect unless explicitly grounded in radiographic signs.
"""


QUERY_PROMPT = """
You will first see an X-ray few-shot table (Question | Ground Truth | Prediction | Correctness). Learn the grading style. Then score the final case by outputting ONLY one number from {{0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}}. Do not output any words or explanations.

**Few-shot (dental X-ray only)**

Question | Ground Truth | Prediction | Correctness
--- | --- | --- | ---
What unusual features stand out in this dental panoramic image? | Caries with endodontic treatment at 23; retained root fragment at 34; alveolar bone resorption at 21, 31, 32, 41, 42, 43; left-sided molar furcation radiolucency. | Retained root at 34; deep caries 23 with root canal filling; anterior mandibular bone loss (31–43) and mild loss at 21; left molar furcation involvement. | 0.9
Are there any visible concerns in this oral panoramic X-ray? | The regions <box>[0.32,0.52,0.37,0.66]</box>, <box>[0.35,0.53,0.41,0.66]</box>, <box>[0.61,0.50,0.73,0.68]</box> contain surgical devices. | Multiple fixation plates and screws (surgical hardware) are present in the same general regions bilaterally. | 0.9
What issues are present in this panoramic view of the oral cavity? | The region <box>[0.45, 0.63, 0.60, 0.69]</box> shows a fixed orthodontic appliance (brackets and archwire). | Fixed braces (brackets with an archwire) are present in the lower molar–premolar segment; coordinates not specified. | 0.8
Can you identify any problems in this oral panoramic image? | Endodontic treatment on 13, 23, 24, 26, 45; carious lesion on 47; alveolar bone resorption near 16, 28, 33, 34, 37, 44, 47; furcation involvement at 37 and 47; multiple prosthetic crowns/bridges. | RCT on 13, 23, 24, 26 (missed 45); caries on 47; generalized posterior bone loss; furcation at 47; multiple crowns. | 0.8
What issues are present in this panoramic view of the oral cavity? | Teeth 48, 38 and 28 are impacted. | Impacted third molars in positions 38 and 48; tooth 28 appears partially erupted but likely normal. | 0.6
Can you identify any problems in this oral panoramic image? | Endodontic treatment on 13, 23, 24, 26, 45; carious lesion on 47; alveolar bone resorption near 16, 28, 33, 34, 37, 44, 47; furcation at 37 and 47. | RCT on 12 and 22; caries on 46; mild bone loss limited to 36–37; no furcation changes. | 0.2
Do you notice any anomalies in this dental panoramic radiograph? | Impaction of tooth 38 (lower left third molar) — unerupted. | Impacted lower right third molar (tooth 48). | 0.1


### Now score the following case:

Question: {question}
Ground Truth: {ground_truth}
Prediction: {prediction}

Output ONLY one value from: 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0
"""

def call_gpt_api(messages, api_key, api_host, model="gpt-5-nano-2025-08-07", 
                 max_tokens=16384, temperature=0.2, max_retries=5, timeout=240):
    """
    Call GPT API with provided messages and return the response
    
    Args:
        messages: List of message dictionaries with role and content
        api_key: API key for authentication
        api_host: API host address
        model: Model to use
        max_tokens: Maximum tokens in response
        temperature: Temperature parameter for generation
        max_retries: Maximum number of retry attempts
        timeout: Request timeout in seconds
    
    Returns:
        Response content as string
    """
    
    # Build the request payload
    payload_dict = {
        "model": model,
        "stream": False,  # Non-streaming response
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    
    payload = json.dumps(payload_dict)
    
    # Set up request headers
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {api_key}',
    }
    
    last_err = None
    
    for attempt in range(1, max_retries + 1):
        try:
            print(f"  🔄 API call ({attempt}/{max_retries})")
            
            # Create HTTPS connection and make request
            conn = http.client.HTTPSConnection(api_host, timeout=timeout)
            conn.request("POST", "/v1/chat/completions", payload, headers)
            resp = conn.getresponse()
            data = resp.read().decode("utf-8", errors="ignore")
            conn.close()

            # Check for HTTP errors
            if resp.status < 200 or resp.status >= 300:
                raise RuntimeError(f"HTTP {resp.status}: {data[:500]}")

            # Parse response JSON
            j = json.loads(data)
            choices = j.get("choices", [])
            if not choices:
                raise ValueError("Response has no choices")
                
            msg = choices[0].get("message", {})
            content = msg.get("content") or msg.get("text")
            
            # Handle content that might be a list
            if isinstance(content, list):
                content = "\n".join([c if isinstance(c, str) else c.get("text", "") for c in content])
            
            content = (content or "").strip()
            if not content:
                raise ValueError("Response content is empty")
            
            print(f"  ✅ API call successful")
            return content
            
        except Exception as e:
            last_err = e
            print(f"  ❌ Failed: {e}")
            if attempt < max_retries:
                backoff = min(2 ** attempt, 15)  # Exponential backoff
                print(f"  ⏳ Waiting {backoff} seconds before retry...")
                time.sleep(backoff)
    
    raise last_err if last_err else RuntimeError("API call failed")


class GPT4VisionClient:
    """Client for interacting with GPT-4 Vision API"""

    def __init__(self, endpoint=None, api_key=None):
        self.api_key = api_key or os.environ.get("API_KEY", "")
        self.api_host = endpoint or os.environ.get("API_HOST", "jeniya.top")

    def query(
        self, images, prompt: str, system_prompt: str = None, max_retries=5, initial_delay=3
    ) -> str:
        """Query GPT-4 Vision with an image and prompt"""

        data_url_list = []
        for image in images:
            # get_image_data_url 外部未定义：添加一个简易兜底实现避免 NameError。
            # TODO: 如果真实环境已有该函数（例如在其它模块中封装转换为 data URL），请改为正确导入。
            def _fallback_get_image_data_url(img_path):
                # 简单用 file:// 协议占位，具体视觉 API 可能需要 base64 编码。
                # 返回一个可被 image_url 使用的字符串。请根据真实 API 进行替换。
                return f"file://{img_path}"
            try:
                data_url = get_image_data_url(image)  # type: ignore
            except Exception:
                data_url = _fallback_get_image_data_url(image)
            data_url_list.append(data_url)

        if system_prompt is not None:
            messages = [
                {
                    "role": "system",
                    "content": [
                        {"type": "text", "text": system_prompt},
                    ],
                },
            ]
        else:
            messages = []
        messages.append(
            {
                "role": "user",
                "content": [
                ],
            }
        )

        for data_url in data_url_list:
            messages[-1]["content"].append(
                {"type": "image_url", "image_url": {"url": data_url}}
            )

        messages[-1]["content"].append({"type": "text", "text": prompt})

        attempt = 0
        while attempt < max_retries:
            try:
                temperature = min(0.2 * attempt, 1.0)
                
                response_text = call_gpt_api(
                    messages=messages,
                    api_key=self.api_key,
                    api_host=self.api_host,
                    # model="gpt-5-mini-2025-08-07",
                    model="gpt-5-nano-2025-08-07",
                    max_tokens=16394,
                    temperature=temperature,
                    max_retries=1,  # Handle retries at this level
                    timeout=120
                )

                # if 'score:' not in response_text.lower():
                #     raise ValueError(f"No 'score:' in response: {response_text}")

                # extract_score = response_text.lower().split("score:")[-1].strip().split("\n")[0].strip().split(" ")[0]
                # if "1" not in extract_score and '0' not in extract_score:
                #     raise ValueError("No '0' nor '1' in the response: {}".format(extract_score))
                # 提取并清理响应文本
                extract_score = response_text.strip().split("\n")[0].strip().split()[0]

                # 尝试转换为浮点数
                try:
                    score = float(extract_score)
                except ValueError:
                    raise ValueError(f"Cannot convert to float: {extract_score}")

                # 验证分数是否在有效范围内
                valid_scores = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
                if score not in valid_scores:
                    raise ValueError(f"Invalid score: {score}. Must be one of {valid_scores}")

                return extract_score
                
            except Exception as e:
                print("="*100)
                print(str(e))
                print("messages: ", messages)
                print("="*100)
                delay = 3
                time.sleep(delay)
            attempt += 1
            
        print(f"Warning: Failed after {max_retries} attempts")
        return ""


client = GPT4VisionClient()


def is_valid_direct_answer(response, direct_answer_format) -> bool:
    """
    对 <think>...</think><answer>...</answer> 的形式进行校验：
      1) 是否整体匹配大体结构
      2) 是否只出现一次 <think>...</think> 和 <answer>...</answer>
      3) 不应包含 <tool_call> </tool_call>
    """
    pattern = direct_answer_format
    # 1). Structure Matching
    if not re.match(pattern, response, re.DOTALL):
        return False
    # 2). Pattern Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    if response.count('<answer>') != 1 or response.count('</answer>') != 1:
        return False
    # 3). <tool_call> </tool_call> is not allowed!
    if '<tool_call>' in response or '</tool_call>' in response:
        return False
    return True

def is_valid_direct_answer_grounding(response, direct_answer_format) -> bool:
    """
    对 <think>...</think><answer>...</answer> 的形式进行校验：
      1) 是否整体匹配大体结构
      2) 是否只出现一次 <think>...</think> 和 <answer>...</answer>
      3) 不应包含 <tool_call> </tool_call>
    """
    pattern = direct_answer_format
    # 1). Structure Matching
    if not re.match(pattern, response, re.DOTALL):
        return False
    # 2). Pattern Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    if response.count('<answer>') != 1 or response.count('</answer>') != 1:
        return False
    # 3). <tool_call> </tool_call> is not allowed!
    if '<grounding>' in response or '</grounding>' in response:
        return False
    #####added by fyx start
    if '<mirror_grounding>' in response or '</mirror_grounding>' in response:
        return False
    #####added nu fyx end
    return True

def is_valid_tool_call(response, step_tool_call_format) -> bool:
    """
    对 <think>...</think>...<tool_call>...</tool_call> 的形式进行校验：
      1) 整体正则匹配
      2) <think>...</think> 各出现一次
      3) <tool_call>...</tool_call> 只出现一次
      4) 不应出现 <answer> </answer>
    """
    pattern = step_tool_call_format
    # 1). Structure Matching
    # if not re.match(pattern, response, re.DOTALL):
    #####added by fyx start
    normalized_response = response.replace('<mirror_grounding>', '<grounding>').replace('</mirror_grounding>', '</grounding>')
    if not re.match(pattern, normalized_response, re.DOTALL):
    #####added nu fyx end
        return False
    # 2). <think> Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    # 3). <tool_call> </tool_call> Count
    if response.count('<tool_call>') != 1 and response.count('</tool_call>') != 1:
        return False
    # 4). <answer> or </answer> is not allowed!
    if '<answer>' in response or '</answer>' in response:
        return False
    return True

def is_valid_tool_call_grounding(response, step_tool_call_format) -> bool:
    """
    对 <think>...</think>...<tool_call>...</tool_call> 的形式进行校验：
      1) 整体正则匹配
      2) <think>...</think> 各出现一次
      3) <tool_call>...</tool_call> 只出现一次
      4) 不应出现 <answer> </answer>
    """
    pattern = step_tool_call_format
    # 1). Structure Matching
    if not re.match(pattern, response, re.DOTALL):
        return False
    # 2). <think> Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    # 3). <tool_call> </tool_call> Count
    # if response.count('<grounding>') != 1 and response.count('</grounding>') != 1:
    #####added by fyx start
    grounding_open_count = response.count('<grounding>') + response.count('<mirror_grounding>')
    grounding_close_count = response.count('</grounding>') + response.count('</mirror_grounding>')
    if grounding_open_count != 1 or grounding_close_count != 1:
    #####added nu fyx end
        return False
    # 4). <answer> or </answer> is not allowed!
    if '<answer>' in response or '</answer>' in response:
        return False
    return True

def format_reward(predict_str_list: list, extra_info: dict = None):
    """
    Check if the model's response follows the required formats and return a reward.
    [1-turn]:
        - Direct Answer
    [2-turn]:
        - Call Image Resize Tool + Answer
    Args:
    - predict_str_list (list): A list of responses, currently, max length of `predict_str_list` is 10 (10-turn), max image num is 2.
    Returns:
    - format_score: float, 1.0 for right format, 0.0 for wrong
    - tool_call_count: int, times of function tools called
    """
    conv_rounds = len(predict_str_list)
    format_score, tool_call_count = 0, 0
    # All allowed formats
    direct_answer_format = r'^<think>.*</think>.*<answer>.*</answer>$'
    step_tool_call_format = r'^<think>.*</think>.*<tool_call>.*</tool_call>$'
    tool_call_pattern = re.compile(r'<tool_call>(.*?)</tool_call>', re.DOTALL)
    # HACK/FIXME: We need more flexible judge in the future
    # 1-turn
    if conv_rounds == 1:
        response = predict_str_list[0].strip()
        tool_call_contents = tool_call_pattern.findall(response)
        if len(tool_call_contents) > 0:
            tool_call_count += 1
        # Direct Answer
        if is_valid_direct_answer(response, direct_answer_format):
            format_score = 1
    # multi-turn
    else:
        tool_call_match_flag = True
        for response in predict_str_list[:-1]:
            response = response.strip()
            tool_call_contents = tool_call_pattern.findall(response)
            if len(tool_call_contents) > 0:
                tool_call_count += 1
            # Call Function Tool
            if not is_valid_tool_call(response, step_tool_call_format):
                tool_call_match_flag = False
                break
        final_answer_match_flag = is_valid_direct_answer(predict_str_list[-1], direct_answer_format)
        if tool_call_match_flag and final_answer_match_flag:
            format_score = 1
    return format_score, tool_call_count


def grounding_format_reward(predict_str_list: list, extra_info: dict = None):
    """
    Check if the model's response follows the required formats and return a reward.
    [1-turn]:
        - Direct Answer
    [2-turn]:
        - Call Image Resize Tool + Answer
    Args:
    - predict_str_list (list): A list of responses, currently, max length of `predict_str_list` is 10 (10-turn), max image num is 2.
    Returns:
    - format_score: float, 1.0 for right format, 0.0 for wrong
    - tool_call_count: int, times of function tools called
    """
    conv_rounds = len(predict_str_list)
    format_score, tool_call_count = 0, 0
    # All allowed formats
    direct_answer_format = r'^<think>.*</think>.*<answer>.*</answer>$'
    step_tool_call_format = r'^<think>.*</think>.*<grounding>.*</grounding>$'
    # tool_call_pattern = re.compile(r'<grounding>(.*?)</grounding>', re.DOTALL)
    #####added by fyx start
    tool_call_pattern = re.compile(r'<(mirror_grounding|grounding)>(.*?)</\1>', re.DOTALL)
    #####added nu fyx end
    # HACK/FIXME: We need more flexible judge in the future
    # 1-turn
    if conv_rounds == 1:
        response = predict_str_list[0].strip()
        tool_call_contents = tool_call_pattern.findall(response)
        if len(tool_call_contents) > 0:
            tool_call_count += 1
        # Direct Answer
        if is_valid_direct_answer_grounding(response, direct_answer_format):
            format_score = 1
    # multi-turn
    else:
        tool_call_match_flag = True
        for response in predict_str_list[:-1]:
            response = response.strip()
            tool_call_contents = tool_call_pattern.findall(response)
            if len(tool_call_contents) > 0:
                tool_call_count += 1
            # Call Function Tool
            if not is_valid_tool_call_grounding(response, step_tool_call_format):
                tool_call_match_flag = False
                break
        final_answer_match_flag = is_valid_direct_answer_grounding(predict_str_list[-1], direct_answer_format)
        if tool_call_match_flag and final_answer_match_flag:
            format_score = 1

    return format_score, tool_call_count


def inner_acc_reward(prompt: str, predict_str_list: list, original_answer: str, use_gpt=False, gpt_extract_answer=False, extra_info=None):
    original_predict_str = ' '.join(predict_str_list)
    if gpt_extract_answer:
        if extra_info['extract_answer_tags'] == 'split':
            original_predict_str = original_predict_str.split("<answer>")[-1].split("</answer>")[0].strip()
        elif extra_info['extract_answer_tags'] == 'strict':
            extract_answer_pattern = r'<answer>(.*?)</answer>'
            match = re.search(extract_answer_pattern, original_predict_str, re.DOTALL)
            if match:
                original_predict_str = match.group(1)
            else:
                reward = 0.0
                return reward
        elif extra_info['extract_answer_tags'] == 'strict_v2':
            print("e1")
            extract_answer_pattern = r'<answer>(.*?)</answer>$'
            match = re.search(extract_answer_pattern, original_predict_str, re.DOTALL)
            if match:
                original_predict_str = match.group(1)
            else:
                reward = 0.0
                return reward
        else:
            raise ValueError("Such value is not implemented for extra_info['extract_answer_tags']: {}".format(extra_info['extract_answer_tags']))
    question = prompt
    prompt = QUERY_PROMPT.format(question=question, ground_truth=original_answer, prediction=original_predict_str)
    response = client.query(images=[], prompt=prompt, system_prompt=SYSTEM_PROMPT)
    
    
    if len(response) == 0:
        reward = {"is_filter": True, "info": "error with gpt4o"}
    else:
        try:
            # 原逻辑这里无论GPT返回0.8/0.9等都会被下面那句二分类覆写为0.0（只有包含'1.0'才返回1.0），导致acc_score几乎总是0。
            # 修复：直接使用GPT返回的离散分值（0.0~1.0），并做健壮解析与边界裁剪，不再二值化。
            raw_first_token = response.strip().split()[0]
            try:
                reward = float(raw_first_token)
            except ValueError:
                # 兜底：尝试从整体字符串中抓第一个形如X.X的数字
                num_match = re.search(r"\b[0-1]\.[0-9]\b", response)
                if num_match:
                    reward = float(num_match.group())
                else:
                    raise ValueError(f"Cannot parse numeric score from response: {response}")
            # 裁剪并保留一位小数（因为允许的集合是0.0~1.0步长0.1）
            reward = round(max(0.0, min(1.0, reward)), 1)
        except (ValueError, TypeError):
            # 如果转换失败，返回错误信息
            reward = {"is_filter": True, "info": "invalid response format"}
    return reward

def acc_reward(prompt: str, predict_str_list: list, solution: str, extra_info: dict = None) -> float:
    gpt_extract_answer = extra_info.get("gpt_extract_answer", False)
    reward = inner_acc_reward(prompt, predict_str_list, solution, use_gpt=True, gpt_extract_answer=gpt_extract_answer, extra_info=extra_info)
    return reward

def compute_score(prompt: str, predict_str_list: list, ground_truth: list, extra_info: dict = None) -> float:
    acc_reward_weight = extra_info.get('acc_reward_weight', 1.0) if extra_info else 1.0
    format_reward_weight = extra_info.get('format_reward_weight', 1.0) if extra_info else 1.0
    tool_call_penalty = 0.1
    if extra_info is not None and 'tool_call_penalty' in extra_info:
        tool_call_penalty = extra_info.get('tool_call_penalty', 0.1)

    condition_reward_value = extra_info.get('condition_tool_reward', 0.5) if extra_info else 0.5
    condition_acc_threshold = extra_info.get('condition_tool_acc_threshold', 0.5) if extra_info else 0.5

    acc = acc_reward(prompt, predict_str_list, ground_truth, extra_info)
    if isinstance(acc, dict):
        return acc

    format_score, tool_call_count = grounding_format_reward(predict_str_list, extra_info)

    acc_score = acc_reward_weight * acc
    print(f"------------->acc_score: {acc_score}")
    format_score = format_reward_weight * format_score

    condition_reward = 0.0
    # Encourage tool calls only when they contribute to strong answers
    if acc > condition_acc_threshold and tool_call_count > 0:
        condition_reward = condition_reward_value

    tool_penalty_factor = (1 - tool_call_penalty) if tool_call_count > 0 else 1.0
    tool_reward = extra_info.get('use_tool_reward_weight', 0.0) if tool_call_count > 0 else 0.0
    score = tool_penalty_factor * acc_score + format_score + tool_reward + condition_reward

    return score, acc_score, format_score

if __name__ == '__main__':
    question = "Elena Ferrante"
    predict_str = ["""<think>To determine the name of the store with a blue sign, I\'ll need to look closely at the sign. The image shows a building with several signs, and one of them is blue and located to the right of the gray baffle. I\'ll zoom in on that area to read the sign clearly.</think> <grounding>{"bbox_2d": [2761, 715, 3160, 896]}</grounding>""", """<think>To determine the name of the store with a blue sign</think> <answer>The name of the store with a blue sign is "J&optica." </answer>"""]
    ground_truth = "Jptica"
    extra_info = {
        "acc_reward_weight": 1.0,
        "format_reward_weight": 0.5,
        "use_tool_reward_weight": 0.5,
        "gpt_extract_answer": True,
        "extract_answer_tags": "strict",
    }
    # s1 = compute_score(question, predict_str, ground_truth, extra_info)
    # print(s1)

    s2 = grounding_format_reward(predict_str, extra_info)
    print(s2)