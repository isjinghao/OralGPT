"""General QA tool reward with curiosity shaping.

This module keeps the existing GPT-based accuracy evaluation from
``general_qa_tool_condition`` but augments the reward with a curiosity term
that incentivises judicious tool usage. The implementation is inspired by the
curiosity shaping design used in Pixel-Reasoner.
"""

from __future__ import annotations

from collections import deque
from typing import Dict, List, Mapping, Tuple, Union

from . import general_qa_tool_condition as base_condition

Number = Union[int, float]
Scalar = Union[Number, str, bool]
ResultDict = Dict[str, Scalar]

# A small buffer that tracks recent tool adoption so we can approximate the
# per-prompt usage rate ("rapr") described in the curiosity design doc.
# _TOOL_USAGE_HISTORY: deque[float] = deque(maxlen=256)
_TOOL_USAGE_HISTORY: deque[float] = deque(maxlen=64)


def _estimate_adoption_rate() -> float:
    """Return the smoothed fraction of recent samples that called tools."""
    if not _TOOL_USAGE_HISTORY:
        return 0.0
    history_sum = sum(_TOOL_USAGE_HISTORY)
    history_len = len(_TOOL_USAGE_HISTORY)
    return history_sum / history_len


def _record_tool_usage(tool_used: bool) -> None:
    """Update the running window with the latest tool usage signal."""
    _TOOL_USAGE_HISTORY.append(1.0 if tool_used else 0.0)


def _compute_curiosity_bonus(
    tool_call_count: int,
    base_score: float,
    adoption_rate: float,
    extra_info: Mapping[str, Scalar],
) -> float:
    """Compute the curiosity shaping term for image-only tasks."""
    if tool_call_count <= 0:
        return 0.0

    if base_score <= extra_info.get("curiosity_min_score", 0.3):
        return 0.0

    # Parameters follow the Pixel-Reasoner design while allowing overrides.
    target_usage = extra_info.get("curiosity_target_usage", 0.3)
    adoption_divisor = extra_info.get("curiosity_image_divisor", 2.0)
    max_bonus = extra_info.get("curiosity_max_bonus", 0.25)
    penalty_factor = extra_info.get("curiosity_penalty_factor", 0.05)
    discount = extra_info.get("curiosity_discount", 1.0)

    usage_gap = max(target_usage - adoption_rate, 0.0)
    curiosity = usage_gap / adoption_divisor

    adoption_rate = max(adoption_rate, 1e-3)
    curiosity = min(curiosity / adoption_rate * max_bonus, max_bonus)

    penalty = -penalty_factor * max(tool_call_count - 1, 0)

    return discount * (curiosity + penalty)


def compute_score(
    prompt: str,
    predict_str_list: List[str],
    ground_truth,
    extra_info: Dict[str, Scalar] | None = None,
) -> Union[Tuple[float, float, float], ResultDict]:
    """Compute the reward with curiosity shaping for tool-based QA."""
    extra_info = extra_info or {}

    if isinstance(predict_str_list, str):
        predict_str_list = [predict_str_list]

    acc_reward_weight = extra_info.get("acc_reward_weight", 1.0)
    format_reward_weight = extra_info.get("format_reward_weight", 1.0)
    tool_call_penalty = extra_info.get("tool_call_penalty", 0.1)

    format_score_raw, tool_call_count = base_condition.grounding_format_reward(
        predict_str_list, extra_info
    )

    tool_used = tool_call_count > 0
    adoption_rate = _estimate_adoption_rate()

    acc = base_condition.acc_reward(prompt, predict_str_list, ground_truth, extra_info)
    if isinstance(acc, dict):
        # Keep adoption history consistent even if the GPT grader filters this sample.
        _record_tool_usage(tool_used)
        return acc

    curiosity_bonus = 0.0
    curiosity_positive = 0.0
    curiosity_penalty = 0.0
    trigger_flag = 0.0

    if tool_used:
        threshold = extra_info.get("curiosity_min_score", 0.3)
        if acc > threshold:
            curiosity_bonus = _compute_curiosity_bonus(
                tool_call_count=tool_call_count,
                base_score=acc,
                adoption_rate=adoption_rate,
                extra_info=extra_info,
            )
            trigger_flag = 1.0
            target_usage = extra_info.get("curiosity_target_usage", 0.3)
            adoption_divisor = extra_info.get("curiosity_image_divisor", 2.0)
            max_bonus = extra_info.get("curiosity_max_bonus", 0.25)
            penalty_factor = extra_info.get("curiosity_penalty_factor", 0.05)
            discount = extra_info.get("curiosity_discount", 1.0)

            usage_gap = max(target_usage - adoption_rate, 0.0)
            curiosity_positive = usage_gap / adoption_divisor
            adoption_rate_safe = max(adoption_rate, 1e-3)
            curiosity_positive = min(curiosity_positive / adoption_rate_safe * max_bonus, max_bonus)
            curiosity_positive = discount * curiosity_positive
            curiosity_penalty = -penalty_factor * max(tool_call_count - 1, 0)
            curiosity_penalty = discount * curiosity_penalty

    # Record the latest decision after computing the bonus so future calls see it.
    _record_tool_usage(tool_used)

    adjusted_acc = max(0.0, min(1.0, acc + curiosity_bonus))
    acc_score = acc_reward_weight * adjusted_acc
    format_score = format_reward_weight * format_score_raw

    tool_penalty_factor = (1 - tool_call_penalty) if tool_used else 1.0
    tool_reward = extra_info.get("use_tool_reward_weight", 0.0) if tool_used else 0.0

    score = tool_penalty_factor * acc_score + format_score + tool_reward

    curiosity_metrics: ResultDict = {
        "curiosity_bonus": float(curiosity_bonus),
        "curiosity_positive": float(curiosity_positive),
        "curiosity_penalty": float(curiosity_penalty),
        "curiosity_trigger": float(trigger_flag),
        "curiosity_tool_calls": float(tool_call_count),
        "curiosity_adoption": float(adoption_rate),
        "curiosity_base_acc": float(acc),
        "curiosity_adjusted_acc": float(adjusted_acc),
    }

    return score, acc_score, format_score, curiosity_metrics
