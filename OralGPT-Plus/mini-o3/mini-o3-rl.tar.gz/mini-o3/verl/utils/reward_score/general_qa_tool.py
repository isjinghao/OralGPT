import re
import os
import time
import json
import http.client

# SYSTEM_PROMPT = "You are a chatbot that evaluates if predicted answers match correct answers for question-answer pairs. Compare predictions with ground truth, accepting synonyms and paraphrases as valid matches."
SYSTEM_PROMPT = """
You are an expert judge for a benchmark on dental panoramic X-ray image. Your job is to strictly evaluate how correct a model's prediction is compared to the ground truth (GT).

Output rule:
- Output ONLY a single numeric score from this set: 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0. No words, no symbols, no explanations.

Clinical evaluation rules:
- Judge clinical meaning, not wording; accept clinically equivalent synonyms, such as:
  * "orthodontic appliance" ≈ "fixed braces/brackets + archwire"
  * "surgical device/hardware" ≈ "fixation plate/screws/osteosynthesis hardware"
  * "prosthetic restoration" ≈ "crown/bridge/veneer"
  * "impaction" ≈""unerupted third molar"
- Accept equivalent tooth numbering systems (FDI / Universal / Palmer).
- Coordinates may be absolute or normalized <box>[x1,y1,x2,y2]</box>. If boxes are omitted but the clinical meaning is the same, treat as a minor omission.
- Penalize mismatched diseases/abnormalities/conditions as a major error.
- If prediction asserts additional findings that contradict GT or are clinically false, treat as a major error.
- Do not over-penalize phrasing; do penalize missing core findings.

Scoring guide:
- 1.0: Fully correct—matches GT on all clinically material aspects; no extra wrong claims.
- 0.7–0.9: Mostly correct—only minor omissions (e.g., missing non-critical boxes) or clinically insignificant imprecision; no contradiction to GT.
- 0.3–0.6: Partially correct—some correct elements but misses ≥1 core aspect or introduces a major error.
- 0.1–0.2: Largely incorrect—minimal overlap with GT.
- 0.0: Totally incorrect—no meaningful overlap; fundamental contradiction; refusal; generic non-answer.

Modality constraint:
- Images are dental panoramic X-rays only. If a prediction discusses non-radiographic features (colors of mucosa, soft-tissue surface appearance, etc.), treat as incorrect unless explicitly grounded in radiographic signs.
"""

# QUERY_PROMPT = """Evaluate this prediction:

# Question: {question}
# Ground Truth: {ground_truth}
# Prediction: {prediction}

# Criteria:
# - **Relevance**: Does the prediction address the question?
# - **Accuracy**: 
#   (1) Open-ended answers: Does prediction reflect ground truth without factual errors?
#   (2) Definitive answers: Does prediction exactly match ground truth (considering unit conversions)?

# Output only: "Score: 1" (correct) or "Score: 0" (incorrect)"""
QUERY_PROMPT = """
You will first see an X-ray few-shot table (Question | Ground Truth | Prediction | Correctness). Learn the grading style. Then score the final case by outputting ONLY one number from {{0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0}}. Do not output any words or explanations.

**Few-shot (dental X-ray only)**

Question | Ground Truth | Prediction | Correctness
--- | --- | --- | ---
What issues are present in this panoramic view of the oral cavity? | The region <box>[0.45, 0.63, 0.60, 0.69]</box> shows a fixed orthodontic appliance (brackets and archwire). | Fixed braces (brackets with an archwire) are present in the lower molar–premolar segment; coordinates not specified. | 0.8
Are there any visible concerns in this oral panoramic X-ray? | The regions <box>[0.32,0.52,0.37,0.66]</box>, <box>[0.35,0.53,0.41,0.66]</box>, <box>[0.61,0.50,0.73,0.68]</box> contain surgical devices. | Multiple fixation plates and screws (surgical hardware) are present in the same general regions bilaterally. | 0.9
What issues are present in this panoramic view of the oral cavity? | Teeth 48, 38 and 28 are impacted. | Impacted third molars in positions 38 and 48; tooth 28 appears partially erupted but likely normal. | 0.6
Do you notice any anomalies in this dental panoramic radiograph? | Impaction of tooth 38 (lower left third molar) — unerupted. | Impacted lower right third molar (tooth 48). | 0.1
Can you identify any problems in this oral panoramic image? | Endodontic treatment on 13, 23, 24, 26, 45; carious lesion on 47; alveolar bone resorption near 16, 28, 33, 34, 37, 44, 47; furcation involvement at 37 and 47; multiple prosthetic crowns/bridges. | RCT on 13, 23, 24, 26 (missed 45); caries on 47; generalized posterior bone loss; furcation at 47; multiple crowns. | 0.8
What unusual features stand out in this dental panoramic image? | Caries with endodontic treatment at 23; retained root fragment at 34; alveolar bone resorption at 21, 31, 32, 41, 42, 43; left-sided molar furcation radiolucency. | Retained root at 34; deep caries 23 with root canal filling; anterior mandibular bone loss (31–43) and mild loss at 21; left molar furcation involvement. | 0.9
Can you identify any problems in this oral panoramic image? | Endodontic treatment on 13, 23, 24, 26, 45; carious lesion on 47; alveolar bone resorption near 16, 28, 33, 34, 37, 44, 47; furcation at 37 and 47. | RCT on 12 and 22; caries on 46; mild bone loss limited to 36–37; no furcation changes. | 0.2

Don't be too strict. Arise the points.


### Now score the following case:

Question: {question}
Ground Truth: {ground_truth}
Prediction: {prediction}

Output ONLY one value from: 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0
"""

MMORAL_OPG_SYSTEM_PROMPT = """
You are a medical expert specialized in oral radiology. Your task is to evaluate the quality of answers to questions about oral radiographic images (like X-rays of teeth, jaws, etc.).

Please provide a precise evaluation following the scoring system shown in the examples.
"""


def build_mmoral_opg_prompt(question: str, ground_truth: str, prediction: str) -> str:
    prompt = """
Given the question, compare the ground truth and prediction from AI models, to generate a correctness score for the prediction.
The correctness score is 0.0 (totally wrong), 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, or 1.0 (totally right).
Just complete the last space of the correctness score.

Question | Ground truth | Prediction | Correctness
--- | --- | --- | ---
How many teeth are visualized in the radiograph? | 30 teeth are visualized with clear anatomical definition. | 30 | 1.0
How many teeth are visualized in the radiograph? | 30 teeth are visualized with clear anatomical definition. | 29 teeth are visualized with clear anatomical definition. | 0.0
What is the status of the wisdom teeth in the radiograph? | Three wisdom teeth are detected, all of which are impacted: #18, #28, and #48. | #18: impacted, #28: impacted, #48: erupted | 0.7
What is the condition of the teeth #26 and #14? | Teeth #26 and #14 show signs of periapical abscesses. | Teeth #26 and #23 show signs of periapical abscesses. | 0.5
What is the condition of the bone architecture and visible structures in the jaw? | No apparent bone loss is observed. Bilateral mandibular canals and maxillary sinuses are clearly visible. | Bilateral mandibular canals and maxillary sinuses are clearly visible. | 0.5
What is the clinical priority concern regarding the periapical lesions? | Periapical cysts at #11 and #12, and granuloma at #46 require endodontic evaluation. | Periapical lesions at #11, #12, and #46 require endodontic evaluation. | 0.8
What radiographic features are visible in tooth #31 on the panoramic X-ray? | [
{"Teeth position": {"point_2d": [1242, 726]}},
{"Crown": {"box_2d": [1220, 637, 1266, 741]}}
] | Crown | 0.8
What radiographic features are visible in tooth #31 on the panoramic X-ray? | [
{"Teeth position": {"point_2d": [1242, 726]}},
{"Crown": {"box_2d": [1220, 637, 1266, 741]}}
] | Crown at position: [1230, 627, 1276, 750] | 0.9
What radiographic features are visible in tooth #31 on the panoramic X-ray? | [
{"Teeth position": {"point_2d": [1242, 726]}},
{"Crown": {"box_2d": [1220, 637, 1266, 741]}}
] | Teeth at position: {"point_2d": [1242, 726]}},
{Crown at position: {"box_2d": [1230, 627, 1276, 750]}} | 1.0
"""
    sanitized_ground_truth = str(ground_truth).replace('<AND>', ' <AND> ').replace('<OR>', ' <OR> ')
    sanitized_prediction = str(prediction)
    return prompt + '\n' + ' | '.join([question, sanitized_ground_truth, sanitized_prediction, ''])

# SYSTEM_PROMPT = "You are an intelligent chatbot designed for evaluating the correctness of generative outputs for question-answer pairs.\nYour task is to compare the predicted answer with the correct answer and determine if they match meaningfully. Here's how you can accomplish the task:\n--\n##INSTRUCTIONS:\n- Focus on the meaningful match between the predicted answer and the correct answer.\n- Consider synonyms or paraphrases as valid matches.\n- Evaluate the correctness of the prediction compared to the answer."

# QUERY_PROMPT = """I will give you a question related to an image and the following text as inputs:\n\n1. **Question Related to the Image**: {question}\n2. **Ground Truth Answer**: {ground_truth}\n3. **Model Predicted Answer**: {prediction}\n\nYour task is to evaluate the model's predicted answer against the ground truth answer, based on the context provided by the question related to the image. Consider the following criteria for evaluation:\n- **Relevance**: Does the predicted answer directly address the question posed, considering the information provided by the given question?\n- **Accuracy**: Compare the predicted answer to the ground truth answer. You need to evaluate from the following two perspectives:\n(1) If the ground truth answer is open-ended, consider whether the prediction accurately reflects the information given in the ground truth without introducing factual inaccuracies. If it does, the prediction should be considered correct.\n(2) If the ground truth answer is a definitive answer, strictly compare the model's prediction to the actual answer. Pay attention to unit conversions such as length and angle, etc. As long as the results are consistent, the model's prediction should be deemed correct.\n**Output Format**:\nYour response should include an integer score indicating the correctness of the prediction: 1 for correct and 0 for incorrect. Note that 1 means the model's prediction strictly aligns with the ground truth, while 0 means it does not.\nThe format should be \"Score: 0 or 1\""""


def call_gpt_api(messages, api_key, api_host, model="gpt-5-nano-2025-08-07", 
                 max_tokens=16384, temperature=0.2, max_retries=5, timeout=240):
    """
    Call GPT API with provided messages and return the response
    
    Args:
        messages: List of message dictionaries with role and content
        api_key: API key for authentication
        api_host: API host address
        model: Model to use
        max_tokens: Maximum tokens in response
        temperature: Temperature parameter for generation
        max_retries: Maximum number of retry attempts
        timeout: Request timeout in seconds
    
    Returns:
        Response content as string
    """
    
    # Build the request payload
    payload_dict = {
        "model": model,
        "stream": False,  # Non-streaming response
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    
    payload = json.dumps(payload_dict)
    
    # Set up request headers
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {api_key}',
    }
    
    last_err = None
    
    for attempt in range(1, max_retries + 1):
        try:
            print(f"  🔄 API call ({attempt}/{max_retries})")
            
            # Create HTTPS connection and make request
            conn = http.client.HTTPSConnection(api_host, timeout=timeout)
            conn.request("POST", "/v1/chat/completions", payload, headers)
            resp = conn.getresponse()
            data = resp.read().decode("utf-8", errors="ignore")
            conn.close()

            # Check for HTTP errors
            if resp.status < 200 or resp.status >= 300:
                raise RuntimeError(f"HTTP {resp.status}: {data[:500]}")

            # Parse response JSON
            j = json.loads(data)
            choices = j.get("choices", [])
            if not choices:
                raise ValueError("Response has no choices")
                
            msg = choices[0].get("message", {})
            content = msg.get("content") or msg.get("text")
            
            # Handle content that might be a list
            if isinstance(content, list):
                content = "\n".join([c if isinstance(c, str) else c.get("text", "") for c in content])
            
            content = (content or "").strip()
            if not content:
                raise ValueError("Response content is empty")
            
            print(f"  ✅ API call successful")
            return content
            
        except Exception as e:
            last_err = e
            print(f"  ❌ Failed: {e}")
            if attempt < max_retries:
                backoff = min(2 ** attempt, 15)  # Exponential backoff
                print(f"  ⏳ Waiting {backoff} seconds before retry...")
                time.sleep(backoff)
    
    raise last_err if last_err else RuntimeError("API call failed")


class GPT4VisionClient:
    """Client for interacting with GPT-4 Vision API"""

    def __init__(self, endpoint=None, api_key=None):
        self.api_key = api_key or os.environ.get("API_KEY", "")
        self.api_host = endpoint or os.environ.get("API_HOST", "jeniya.top")

    def query(
        self, images, prompt: str, system_prompt: str = None, max_retries=5, initial_delay=3
    ) -> str:
        """Query GPT-4 Vision with an image and prompt"""

        data_url_list = []
        for image in images:
            # get_image_data_url 外部未定义：添加一个简易兜底实现避免 NameError。
            # TODO: 如果真实环境已有该函数（例如在其它模块中封装转换为 data URL），请改为正确导入。
            def _fallback_get_image_data_url(img_path):
                # 简单用 file:// 协议占位，具体视觉 API 可能需要 base64 编码。
                # 返回一个可被 image_url 使用的字符串。请根据真实 API 进行替换。
                return f"file://{img_path}"
            try:
                data_url = get_image_data_url(image)  # type: ignore
            except Exception:
                data_url = _fallback_get_image_data_url(image)
            data_url_list.append(data_url)

        if system_prompt is not None:
            messages = [
                {
                    "role": "system",
                    "content": [
                        {"type": "text", "text": system_prompt},
                    ],
                },
            ]
        else:
            messages = []
        messages.append(
            {
                "role": "user",
                "content": [
                ],
            }
        )

        for data_url in data_url_list:
            messages[-1]["content"].append(
                {"type": "image_url", "image_url": {"url": data_url}}
            )

        messages[-1]["content"].append({"type": "text", "text": prompt})

        attempt = 0
        while attempt < max_retries:
            try:
                temperature = min(0.2 * attempt, 1.0)
                
                response_text = call_gpt_api(
                    messages=messages,
                    api_key=self.api_key,
                    api_host=self.api_host,
                    model="gpt-5-nano-2025-08-07",
                    max_tokens=16394,
                    temperature=temperature,
                    max_retries=1,  # Handle retries at this level
                    timeout=120
                )

                # if 'score:' not in response_text.lower():
                #     raise ValueError(f"No 'score:' in response: {response_text}")

                # extract_score = response_text.lower().split("score:")[-1].strip().split("\n")[0].strip().split(" ")[0]
                # if "1" not in extract_score and '0' not in extract_score:
                #     raise ValueError("No '0' nor '1' in the response: {}".format(extract_score))
                # 提取并清理响应文本
                extract_score = response_text.strip().split("\n")[0].strip().split()[0]

                # 尝试转换为浮点数
                try:
                    score = float(extract_score)
                except ValueError:
                    raise ValueError(f"Cannot convert to float: {extract_score}")

                # 验证分数是否在有效范围内
                valid_scores = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
                if score not in valid_scores:
                    raise ValueError(f"Invalid score: {score}. Must be one of {valid_scores}")

                return extract_score
                
            except Exception as e:
                print("="*100)
                print(str(e))
                print("messages: ", messages)
                print("="*100)
                delay = 3
                time.sleep(delay)
            attempt += 1
            
        print(f"Warning: Failed after {max_retries} attempts")
        return ""


client = GPT4VisionClient()


def is_valid_direct_answer(response, direct_answer_format) -> bool:
    """
    对 <think>...</think><answer>...</answer> 的形式进行校验：
      1) 是否整体匹配大体结构
      2) 是否只出现一次 <think>...</think> 和 <answer>...</answer>
      3) 不应包含 <tool_call> </tool_call>
    """
    pattern = direct_answer_format
    # 1). Structure Matching
    if not re.match(pattern, response, re.DOTALL):
        return False
    # 2). Pattern Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    if response.count('<answer>') != 1 or response.count('</answer>') != 1:
        return False
    # 3). <tool_call> </tool_call> is not allowed!
    if '<tool_call>' in response or '</tool_call>' in response:
        return False
    return True

def is_valid_direct_answer_grounding(response, direct_answer_format) -> bool:
    """
    对 <think>...</think><answer>...</answer> 的形式进行校验：
      1) 是否整体匹配大体结构
      2) 是否只出现一次 <think>...</think> 和 <answer>...</answer>
      3) 不应包含 <tool_call> </tool_call>
    """
    pattern = direct_answer_format
    # 1). Structure Matching
    if not re.match(pattern, response, re.DOTALL):
        return False
    # 2). Pattern Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    if response.count('<answer>') != 1 or response.count('</answer>') != 1:
        return False
    # 3). <tool_call> </tool_call> is not allowed!
    if '<grounding>' in response or '</grounding>' in response:
        return False
    #####added by fyx start
    if '<mirror_grounding>' in response or '</mirror_grounding>' in response:
        return False
    #####added nu fyx end
    return True

def is_valid_tool_call(response, step_tool_call_format) -> bool:
    """
    对 <think>...</think>...<tool_call>...</tool_call> 的形式进行校验：
      1) 整体正则匹配
      2) <think>...</think> 各出现一次
      3) <tool_call>...</tool_call> 只出现一次
      4) 不应出现 <answer> </answer>
    """
    pattern = step_tool_call_format
    # 1). Structure Matching
    # if not re.match(pattern, response, re.DOTALL):
    #####added by fyx start
    normalized_response = response.replace('<mirror_grounding>', '<grounding>').replace('</mirror_grounding>', '</grounding>')
    if not re.match(pattern, normalized_response, re.DOTALL):
    #####added nu fyx end
        return False
    # 2). <think> Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    # 3). <tool_call> </tool_call> Count
    if response.count('<tool_call>') != 1 and response.count('</tool_call>') != 1:
        return False
    # 4). <answer> or </answer> is not allowed!
    if '<answer>' in response or '</answer>' in response:
        return False
    return True

def is_valid_tool_call_grounding(response, step_tool_call_format) -> bool:
    """
    对 <think>...</think>...<tool_call>...</tool_call> 的形式进行校验：
      1) 整体正则匹配
      2) <think>...</think> 各出现一次
      3) <tool_call>...</tool_call> 只出现一次
      4) 不应出现 <answer> </answer>
    """
    pattern = step_tool_call_format
    # 1). Structure Matching
    if not re.match(pattern, response, re.DOTALL):
        return False
    # 2). <think> Count
    if response.count('<think>') != 1 or response.count('</think>') != 1:
        return False
    # 3). <tool_call> </tool_call> Count
    # if response.count('<grounding>') != 1 and response.count('</grounding>') != 1:
    #####added by fyx start
    grounding_open_count = response.count('<grounding>') + response.count('<mirror_grounding>')
    grounding_close_count = response.count('</grounding>') + response.count('</mirror_grounding>')
    if grounding_open_count != 1 or grounding_close_count != 1:
    #####added nu fyx end
        return False
    # 4). <answer> or </answer> is not allowed!
    if '<answer>' in response or '</answer>' in response:
        return False
    return True

def format_reward(predict_str_list: list, extra_info: dict = None):
    """
    Check if the model's response follows the required formats and return a reward.
    [1-turn]:
        - Direct Answer
    [2-turn]:
        - Call Image Resize Tool + Answer
    Args:
    - predict_str_list (list): A list of responses, currently, max length of `predict_str_list` is 10 (10-turn), max image num is 2.
    Returns:
    - format_score: float, 1.0 for right format, 0.0 for wrong
    - tool_call_count: int, times of function tools called
    """
    conv_rounds = len(predict_str_list)
    format_score, tool_call_count = 0, 0
    # All allowed formats
    direct_answer_format = r'^<think>.*</think>.*<answer>.*</answer>$'
    step_tool_call_format = r'^<think>.*</think>.*<tool_call>.*</tool_call>$'
    tool_call_pattern = re.compile(r'<tool_call>(.*?)</tool_call>', re.DOTALL)
    # HACK/FIXME: We need more flexible judge in the future
    # 1-turn
    if conv_rounds == 1:
        response = predict_str_list[0].strip()
        tool_call_contents = tool_call_pattern.findall(response)
        if len(tool_call_contents) > 0:
            tool_call_count += 1
        # Direct Answer
        if is_valid_direct_answer(response, direct_answer_format):
            format_score = 1
    # multi-turn
    else:
        tool_call_match_flag = True
        for response in predict_str_list[:-1]:
            response = response.strip()
            tool_call_contents = tool_call_pattern.findall(response)
            if len(tool_call_contents) > 0:
                tool_call_count += 1
            # Call Function Tool
            if not is_valid_tool_call(response, step_tool_call_format):
                tool_call_match_flag = False
                break
        final_answer_match_flag = is_valid_direct_answer(predict_str_list[-1], direct_answer_format)
        if tool_call_match_flag and final_answer_match_flag:
            format_score = 1
    return format_score, tool_call_count


def grounding_format_reward(predict_str_list: list, extra_info: dict = None):
    """
    Check if the model's response follows the required formats and return a reward.
    [1-turn]:
        - Direct Answer
    [2-turn]:
        - Call Image Resize Tool + Answer
    Args:
    - predict_str_list (list): A list of responses, currently, max length of `predict_str_list` is 10 (10-turn), max image num is 2.
    Returns:
    - format_score: float, 1.0 for right format, 0.0 for wrong
    - tool_call_count: int, times of function tools called
    """
    conv_rounds = len(predict_str_list)
    format_score, tool_call_count = 0, 0
    # All allowed formats
    direct_answer_format = r'^<think>.*</think>.*<answer>.*</answer>$'
    step_tool_call_format = r'^<think>.*</think>.*<grounding>.*</grounding>$'
    # tool_call_pattern = re.compile(r'<grounding>(.*?)</grounding>', re.DOTALL)
    #####added by fyx start
    tool_call_pattern = re.compile(r'<(mirror_grounding|grounding)>(.*?)</\1>', re.DOTALL)
    #####added nu fyx end
    # HACK/FIXME: We need more flexible judge in the future
    # 1-turn
    if conv_rounds == 1:
        response = predict_str_list[0].strip()
        tool_call_contents = tool_call_pattern.findall(response)
        if len(tool_call_contents) > 0:
            tool_call_count += 1
        # Direct Answer
        if is_valid_direct_answer_grounding(response, direct_answer_format):
            format_score = 1
    # multi-turn
    else:
        tool_call_match_flag = True
        for response in predict_str_list[:-1]:
            response = response.strip()
            tool_call_contents = tool_call_pattern.findall(response)
            if len(tool_call_contents) > 0:
                tool_call_count += 1
            # Call Function Tool
            if not is_valid_tool_call_grounding(response, step_tool_call_format):
                tool_call_match_flag = False
                break
        final_answer_match_flag = is_valid_direct_answer_grounding(predict_str_list[-1], direct_answer_format)
        if tool_call_match_flag and final_answer_match_flag:
            format_score = 1

    return format_score, tool_call_count


def inner_acc_reward(prompt: str, predict_str_list: list, original_answer: str, use_gpt=False, gpt_extract_answer=False, extra_info=None):
    original_predict_str = ' '.join(predict_str_list)
    if gpt_extract_answer:
        if extra_info['extract_answer_tags'] == 'split':
            original_predict_str = original_predict_str.split("<answer>")[-1].split("</answer>")[0].strip()
        elif extra_info['extract_answer_tags'] == 'strict':
            extract_answer_pattern = r'<answer>(.*?)</answer>'
            match = re.search(extract_answer_pattern, original_predict_str, re.DOTALL)
            if match:
                original_predict_str = match.group(1)
            else:
                reward = 0.0
                return reward
        elif extra_info['extract_answer_tags'] == 'strict_v2':
            print("e1")
            extract_answer_pattern = r'<answer>(.*?)</answer>$'
            match = re.search(extract_answer_pattern, original_predict_str, re.DOTALL)
            if match:
                original_predict_str = match.group(1)
            else:
                reward = 0.0
                return reward
        else:
            raise ValueError("Such value is not implemented for extra_info['extract_answer_tags']: {}".format(extra_info['extract_answer_tags']))
    system_prompt_override = SYSTEM_PROMPT
    prompt_builder = None
    prompt_template = None
    if extra_info:
        system_prompt_override = extra_info.get('judge_system_prompt', system_prompt_override)
        prompt_builder = extra_info.get('judge_prompt_builder')
        prompt_template = extra_info.get('judge_query_prompt')

    question = prompt
    if callable(prompt_builder):
        prompt = prompt_builder(question=question, ground_truth=original_answer, prediction=original_predict_str)
    elif isinstance(prompt_template, str):
        prompt = prompt_template.format(question=question, ground_truth=original_answer, prediction=original_predict_str)
    else:
        prompt = QUERY_PROMPT.format(question=question, ground_truth=original_answer, prediction=original_predict_str)

    response = client.query(images=[], prompt=prompt, system_prompt=system_prompt_override)
    
    
    if len(response) == 0:
        reward = {"is_filter": True, "info": "error with gpt4o"}
    else:
        try:
            # 原逻辑这里无论GPT返回0.8/0.9等都会被下面那句二分类覆写为0.0（只有包含'1.0'才返回1.0），导致acc_score几乎总是0。
            # 修复：直接使用GPT返回的离散分值（0.0~1.0），并做健壮解析与边界裁剪，不再二值化。
            raw_first_token = response.strip().split()[0]
            try:
                reward = float(raw_first_token)
            except ValueError:
                # 兜底：尝试从整体字符串中抓第一个形如X.X的数字
                num_match = re.search(r"\b[0-1]\.[0-9]\b", response)
                if num_match:
                    reward = float(num_match.group())
                else:
                    raise ValueError(f"Cannot parse numeric score from response: {response}")
            # 裁剪并保留一位小数（因为允许的集合是0.0~1.0步长0.1）
            reward = round(max(0.0, min(1.0, reward)), 1)
        except (ValueError, TypeError):
            # 如果转换失败，返回错误信息
            reward = {"is_filter": True, "info": "invalid response format"}
    return reward

def acc_reward(prompt: str, predict_str_list: list, solution: str, extra_info: dict = None) -> float:
    gpt_extract_answer = extra_info.get("gpt_extract_answer", False)
    reward = inner_acc_reward(prompt, predict_str_list, solution, use_gpt=True, gpt_extract_answer=gpt_extract_answer, extra_info=extra_info)
    return reward

def compute_score(prompt: str, predict_str_list: list, ground_truth: list, extra_info: dict = None) -> float:
    acc_reward_weight = extra_info.get('acc_reward_weight', 1.0) if extra_info else 1.0
    format_reward_weight = extra_info.get('format_reward_weight', 1.0) if extra_info else 1.0
    tool_call_penalty = 0.1
    if extra_info is not None and 'tool_call_penalty' in extra_info:
        tool_call_penalty = extra_info.get('tool_call_penalty', 0.1)
    acc = acc_reward(prompt, predict_str_list, ground_truth, extra_info)
    if isinstance(acc, dict):
        return acc
    format_score, tool_call_count = grounding_format_reward(predict_str_list, extra_info)

    acc_score = acc_reward_weight * acc
    print(f"------------->acc_score: {acc_score}")
    format_score = format_reward_weight * format_score
    
    tool_penalty_factor = (1 - tool_call_penalty) if tool_call_count > 0 else 1.0
    tool_reward = extra_info.get('use_tool_reward_weight', 0.0) if tool_call_count > 0 else 0.0
    score = tool_penalty_factor * acc_score + format_score + tool_reward

    return score, acc_score, format_score

if __name__ == '__main__':
    question = "Elena Ferrante"
    predict_str = ["""<think>To determine the name of the store with a blue sign, I\'ll need to look closely at the sign. The image shows a building with several signs, and one of them is blue and located to the right of the gray baffle. I\'ll zoom in on that area to read the sign clearly.</think> <grounding>{"bbox_2d": [2761, 715, 3160, 896]}</grounding>""", """<think>To determine the name of the store with a blue sign</think> <answer>The name of the store with a blue sign is "J&optica." </answer>"""]
    ground_truth = "Jptica"
    extra_info = {
        "acc_reward_weight": 1.0,
        "format_reward_weight": 0.5,
        "use_tool_reward_weight": 0.5,
        "gpt_extract_answer": True,
        "extract_answer_tags": "strict",
    }
    # s1 = compute_score(question, predict_str, ground_truth, extra_info)
    # print(s1)

    s2 = grounding_format_reward(predict_str, extra_info)
    print(s2)